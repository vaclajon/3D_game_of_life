3D Game of Life : Sequential programming
===============
To compile program just use provided Makefile (with make command)
Output of compilation is file named test_seq.
To run program use compiled program and insert data to stdin from file
Ex.: ./test_seq < input-100.life
If everything will proceed correctly output will be one line on stdout
Ex.: Time : 2.12200000                                                
and output.life life which contains computed data. 
